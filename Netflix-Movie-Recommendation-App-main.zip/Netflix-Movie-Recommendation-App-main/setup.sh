echo "[theme]
primaryColor = ‘salmon’
backgroundColor = ‘#D3D3D3’
secondaryBackgroundColor = ‘#FFC6A1’
textColor= ‘black’
font = ‘sans serif’
[server]
headless = true
port = $PORT
enableCORS = false
" > ~/.streamlit/config.toml
