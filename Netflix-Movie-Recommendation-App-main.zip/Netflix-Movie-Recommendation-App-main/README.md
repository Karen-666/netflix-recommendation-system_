# Netflix-Movie-Recommendation-App
APP link:https://ruthwik333-netflix-movie-recommendation-app-app-hyy0vu.streamlitapp.com/
#Recommendation system Main Page
![Main1](https://user-images.githubusercontent.com/109128609/180215046-ed35f2e7-5b4e-4795-aeb6-c50cddf4db52.PNG)
Response: Example
![Main2](https://user-images.githubusercontent.com/109128609/180215655-a412ae79-fba8-4617-8ffe-484f9b4778dc.PNG)


